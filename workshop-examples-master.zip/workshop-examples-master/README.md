# Ansible Automation Workshop Examples

This repository contains demo playbooks and roles used in our [Ansible Automation Workshops](https://github.com/ansible/workshops/).

Please note that this content is meant for educational purposes and might contain errors or challenges.

----
![Red Hat Ansible Automation](images/logo-rh-ansible-automation.png)
